﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor_with_SQL.Models;

namespace Razor_with_SQL.Pages
{
	public class EditPageModel : PageModel
    {
        [BindProperty]
        public string id { get; set;}
        [BindProperty]
        public string newEmtion { get; set; }
        [BindProperty]
        public DateTime newTimestamp { get; set; }

        private readonly ILogger<EditPageModel> _logger;
        private readonly DB db;

        public EditPageModel(ILogger<EditPageModel> logger, DB db)
        {
            _logger = logger;
            this.db = db;
        }
        public void OnGet()
        {
        }

        public void OnPost()
        {
            db.update(id,newEmtion, newTimestamp);
        }

    }
}
