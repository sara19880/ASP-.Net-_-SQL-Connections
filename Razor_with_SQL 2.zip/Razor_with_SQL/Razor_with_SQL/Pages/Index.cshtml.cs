﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Data.SqlClient;
using System.Data;
using Razor_with_SQL.Models;
namespace Razor_with_SQL.Pages
{

    public class IndexModel : PageModel

    {
        string _ConStr = "Data Source=localhost,1443; Initial Catalog=SurveyDB; User Id=SA; Password=reallyStrongPwd123";
        private readonly ILogger<IndexModel> _logger;
        private readonly DB db;
        public DataTable dt { get; set; }


        public IndexModel(ILogger<IndexModel> logger, DB db)
        {
            _logger = logger;
            this.db = db;
        }

        public void OnGet()
        {


            //string tableName = "Emotions";
            //string columnNames = "StudentId, Emotion, Timestamp";
            //string values = "202095899, 'Happy', '11:06:39.000'";
            //db.InsertData(tableName, columnNames, values);
            dt = db.ReadTable("Emotions");
        
            
           
        }
    }
}
