﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor_with_SQL.Models;

namespace Razor_with_SQL.Pages
{
    

    public class DeleteModel : PageModel

    {
        [BindProperty]
        public string Id { set; get;}
        private readonly ILogger<DeleteModel> _logger;
        private readonly DB db;

        public DeleteModel(ILogger<DeleteModel> logger, DB db)
        {
            _logger = logger;
            this.db = db;
            
        }

        public void OnPost()
        {
            db.Delete(Id);
        }

    }
}
