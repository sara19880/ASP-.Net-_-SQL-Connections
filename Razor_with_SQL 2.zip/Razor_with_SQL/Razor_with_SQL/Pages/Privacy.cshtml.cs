﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Razor_with_SQL.Models;

namespace Razor_with_SQL.Pages
{

    public class PrivacyModel : PageModel
    {
        private readonly ILogger<PrivacyModel> _logger;
        [BindProperty]
        public string Student_ID { get; set; }

        [BindProperty]
        public string Emotion { get; set; }
        [BindProperty]

        public DateTime Timestamp { get; set; }
        private readonly DB db;

        public PrivacyModel(ILogger<PrivacyModel> logger, DB db)
        {
            _logger = logger;
            this.db = db;
        }

        public void OnGet()
        {
        }


        public void OnPost()
        {
            db.Insert(Student_ID, Emotion, Timestamp);
        }
        //public void OnPost()
        //{
        //    string tableName = "Emotions";
        //    string columnNames = "StudentId, Emotion, Timestamp";
        //    string values = $"'{Student_ID}', '{Emotion}', '{Timestamp}'";
        //    db.InsertData(tableName, columnNames, values);


        //}
    }
}


