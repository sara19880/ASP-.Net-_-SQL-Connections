﻿using System;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Extensions.Logging;
using System.Reflection.PortableExecutable;

namespace Razor_with_SQL.Models
{
	public class DB
	{
        

		public SqlConnection connection;

        public DB()
		{
			string connection_string = "Data Source=localhost,1433; Initial Catalog=SurveyDB; User Id=SA; Password=reallyStrongPwd123";
            connection = new SqlConnection(connection_string);

        }

		public DataTable ReadTable(string tablename)
		{
			DataTable dt = new DataTable();

			string query = "select * from "+tablename;
			Console.WriteLine(query);

			if(connection.State == ConnectionState.Open) {
                SqlCommand cmd = new SqlCommand(query, connection);
                dt.Load(cmd.ExecuteReader());
                return dt;
			}
			else
			{
				connection.Open();

                SqlCommand cmd = new SqlCommand(query, connection);
                dt.Load(cmd.ExecuteReader());
				return dt;

            }

            

			
		}

        //public void InsertData(string tableName, string columnName, string values)
        //{
        //	string query = $"INSERT INTO {tableName} ({columnName}) VALUES ({values})";


        //          if (connection.State == ConnectionState.Open)
        //          {
        //              SqlCommand command2 = new SqlCommand(query, connection);
        //              command2.ExecuteNonQuery();
        //	}
        //	else
        //	{
        //		connection.Open();
        //              SqlCommand command2 = new SqlCommand(query, connection);
        //              command2.ExecuteNonQuery();
        //          }



        //}


        public void Insert(string StudentId, string Emotion, DateTime Timestamp)
        {
            string query = "INSERT INTO Emotions (StudentId, Emotion, Timestamp) VALUES (@StudentId, @Emotion, @Timestamp)";

            if (connection.State == ConnectionState.Open)
            {
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentId", StudentId);
                command.Parameters.AddWithValue("@Emotion", Emotion);
                command.Parameters.AddWithValue("@Timestamp", Timestamp);
                command.ExecuteNonQuery();
            }
            else
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentId", StudentId);
                command.Parameters.AddWithValue("@Emotion", Emotion);
                command.Parameters.AddWithValue("@Timestamp", Timestamp);
                command.ExecuteNonQuery();
                connection.Close(); 
            }
        }


        public void update(string StudentId, string Emotion, DateTime Timestamp)
        {
            string query = "UPDATE Emotions SET  Emotion= @Emotion,TimeStamp=@TimeStamp WHERE StudentId =@StudentId";
            if (connection.State == ConnectionState.Open)
            {
                
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentId",StudentId);
                command.Parameters.AddWithValue("@Emotion", Emotion);
                command.Parameters.AddWithValue("@Timestamp", Timestamp);
                command.ExecuteNonQuery();
            }
            else
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentId",StudentId);
                command.Parameters.AddWithValue("@Emotion", Emotion);
                command.Parameters.AddWithValue("@Timestamp", Timestamp);
                command.ExecuteNonQuery();
            }


        }

        public void Delete(string StudentId)
        {
            string query = "DELETE FROM Emotions WHERE StudentId = @StudentId";
            if (connection.State == ConnectionState.Open)
            {

                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentId", StudentId);
       
                command.ExecuteNonQuery();
            }
            else
            {
                connection.Open();
                SqlCommand command = new SqlCommand(query, connection);
                command.Parameters.AddWithValue("@StudentId", StudentId);
                command.ExecuteNonQuery();
            }


        }

    }
}

